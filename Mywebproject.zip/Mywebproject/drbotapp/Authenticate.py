import requests
import re





username = 'admin'
password = 'QPwoei@10'

URL = 'http://loxtipl001087.mioffice.cn/v1/authentication'

data = {'username':username,'password':password}

r = requests.post(url = URL, json = data)

token = r.text
print(token)

pattren= re.compile('{"token":"([A-Za-z0-9\W\_*]+)","user":')
Extrctd_Token= pattren.search(token)
FinalToken=Extrctd_Token.group(1)
print('The final token is ' +FinalToken)

headers = {'content-type': 'application/json', 'X-Authorization': FinalToken}

payload = {
    "sort": [
        {
            "field": "createdOn",
            "direction": "desc"
        }
    ],
    "filter": {
        "operator": "and",
        "operands": [
            {
                "operator": "gt",
                "field": "createdOn",
                "value": "2020-04-01T00:00:00.001Z"
            },
            {
                "operator": "lt",
                "field": "createdOn",
                "value": "2020-05-31T23:59:59.999Z"
            },
            {
                "operator": "eq",
                "field": "status",
                "value": "Unsuccessful"
            },
            {
                "operator": "substring",
                "field": "activityType",
                "value": "LOGIN"
            }
        ]
    },
    "fields": [],
    "page": {
        "length": "1000",
        "offset": "0"
    }
}

r = requests.post(url='http://loxtipl001087.mioffice.cn/v1/audit/messages/list', headers=headers, json=payload,
                  verify=False)

r = r.json()
print(r)
        


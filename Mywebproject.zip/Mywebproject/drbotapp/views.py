from django.shortcuts import render, HttpResponse, redirect
from django.http import HttpResponse
import json
from django.http import Http404
from .forms import UserForm, UserFormRegister
from .models import Contact,tblConfig,rparobotconfig,rpaserverConfig,rpabotmachine,rpaappinfo,rpadevice,rpafileid,scheduleBot
from datetime import datetime
from django.contrib import messages
from .Authenticate import Authenticate
from .DeviceID import DeviceID
from .File import File
from .ScheduleBot import ScheduleBot
from .Deploy import Deploy
from .BotActivities import BotActivities
from .forms import rpaserverConfigForm,rpadeviceConfigForm

# Extra Imports for the Login and Logout Capabilities
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User, auth

from .models import tblConfig
from .process_check import get_size,get_processes_info,construct_dataframe
# Create your views here.

def index(request):
    return render(request,'drbotapp/index.html')

@login_required
def special(request):
    # Remember to also set login url in settings.py!
    # LOGIN_URL = '/basic_app/user_login/'
    return HttpResponse("You are logged in. Nice!")

@login_required
def user_logout(request):
    # Log out the user.
    logout(request)
    # Return to homepage.
    return HttpResponseRedirect(reverse('index'))

def services(request):
    return render(request, 'drbotapp/services.html')
    #return HttpResponse("this is services")

def about(request):
    return render(request, 'drbotapp/about.html')
   # return HttpResponse("this is about")


def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact= Contact(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent!')
    return render(request, 'drbotapp/contact.html')



def user_login(request):

    if request.method == 'POST':
        # First get the username and password supplied
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Django's built-in authentication function:
        user = authenticate(username=username, password=password)

        # If we have a user
        if user:
            # Check it the account is active
            if user.is_active:
                # Log the user in.
                login(request, user)
                # Send the user back to some page.
                # In this case their homepage.
                # tblConfs = tblConfig.objects.all()
                # return render(request, 'drbotapp/home.html', {'drbotdetail': tblConfs})
                return HttpResponseRedirect(reverse('index'))
            else:
                # If account is not active:
                return HttpResponse("Your account is not active.")
        else:
            print(authenticate(username=username, password=password))
            print("They used username: {} and password: {}".format(username, password))
            return HttpResponse("Invalid login details supplied.")

    else:
        # Nothing has been provided for username or password.
        loginpg = UserForm()
        return render(request,'drbotapp/Login.html',{'drbotlogin': loginpg})


@login_required
def home(request):
    return render(request, 'drbotapp/home.html')


# def configuration(request):
#     user_frmvalues = UserFormRegister()
#     user_profile = UserProfileForm()
#     return render(request,'drbotapp/configure.html' ,{'user_config': user_frmvalues,'profil_Config': user_profile })

@login_required
def configdetail(request,id):

    try:
        tblConf = tblConfig.objects.get(id=id)
    except tblConfig.DoesNotExist:
        raise Http404('Config not found')
    return render(request,'drbotapp/configdetail.html', {'tblConf':tblConf} )



def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'usernameTaken')
                print('username taken')
                return redirect('register')

            elif User.objects.filter(email=email).exists():
                messages.info(request, 'email-Id Is Already Exits')
                print('email exits')
                return redirect('register')

            else:
                user = User.objects.create_user(username=username, password=password1, first_name=first_name,
                                                last_name=last_name, email=email)
                user.save()
                print('user created')
                return redirect("/")


        else:
            print('password not matched')
            return redirect('register')
            # return redirect("/")
    else:
        return render(request, 'drbotapp/register.html')


@login_required
def manageRobot(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            botname = request.POST.get('botname')
            botdesc = request.POST.get('botdesc')
            botServerID = request.POST.get('botServerID')
            botinfo = rparobotconfig(botname=botname, botdesc=botdesc, botServerID=botServerID)
            botinfo.save()
            messages.success(request, 'Data Saved!')
        rpadata = rparobotconfig.objects.all()
        return render(request, 'drbotapp/monitorRobot.html', {'monitorBot': rpadata})
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))

def monitorRobot(request):
    if request.user.is_authenticated:
        rpadata = rparobotconfig.objects.all()
        return render(request, 'drbotapp/monitorRobot.html', {'monitorBot': rpadata})
        # return HttpResponseRedirect(reverse('index'))
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))
# @login_required
# def manageServer(request):
#     if request.user.is_authenticated:
#         if request.method == "POST":
#             applob = request.POST.get('applob')
#             appname = request.POST.get('appname')
#             appUrl = request.POST.get('appUrl')
#             appAPIkey = request.POST.get('appAPIkey')
#             param = request.POST.get('param')
#             serverinfo = rpaserverConfig(applob=applob, appname=appname, appUrl=appUrl,appAPIkey = appAPIkey,param=param)
#             serverinfo.save()
#             messages.success(request, 'Data Saved!')
#         rpasvrr = rpaserverConfig.objects.all()
#         return render(request, 'drbotapp/monitorServer.html', {'monitorSvr': rpasvrr})
#     else:
#         # Nothing has been provided for username or password.
#         # loginpg = UserForm()
#         # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
#         return HttpResponseRedirect(reverse('index'))

# def monitorServer(request):
#     if request.user.is_authenticated:
#         rpasvrr = rpaserverConfig.objects.all()
#         return render(request, 'drbotapp/monitorServer.html', {'monitorSvr': rpasvrr})
#         # return HttpResponseRedirect(reverse('index'))
#     else:
#         # Nothing has been provided for username or password.
#         # loginpg = UserForm()
#         # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
#         return HttpResponseRedirect(reverse('index'))
@login_required
def manageMachine(request):
    if request.user.is_authenticated:
            if request.method == "POST":
                machinename = request.POST.get('machinename')
                machineIP = request.POST.get('machineIP')
                machinedesc = request.POST.get('machinedesc')
                RPAServerID = request.POST.get('RPAServerID')
                tbleinfo = rpabotmachine(machinename=machinename, machineIP=machineIP, machinedesc=machinedesc,RPAServerID = RPAServerID)
                tbleinfo.save()
                messages.success(request, 'Data Saved!')
                # return render(request, 'drbotapp/monitorMachine.html')
            rpadata = rpabotmachine.objects.all()
            # rpadata = construct_dataframe(get_processes_info())
            # Htm = rpadata.to_html()
            return render(request, 'drbotapp/monitorMachine.html', {'monitorMachine': rpadata})
            # return HttpResponseRedirect(reverse('index'))
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))

# def monitorMachine(request):
#     if request.user.is_authenticated:
#         rpadata = rpabotmachine.objects.all()
#         # rpadata = construct_dataframe(get_processes_info())
#         # Htm = rpadata.to_html()
#         return render(request, 'drbotapp/monitorMachine.html', {'monitorMachine': rpadata})
#         # return HttpResponseRedirect(reverse('index'))
#     else:
#         # Nothing has been provided for username or password.
#         # loginpg = UserForm()
#         # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
#         return HttpResponseRedirect(reverse('index'))
@login_required
def manageApp(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            appname = request.POST.get('machinename')
            appdesc = request.POST.get('machineIP')
            applob = request.POST.get('machinedesc')
            tbleinfo = rpaappinfo(appname=appname, appdesc=appdesc, applob=applob)
            tbleinfo.save()
            messages.success(request, 'Data Saved!')
        rpadata = rpaappinfo.objects.all()
        return render(request, 'drbotapp/monitorApp.html', {'monitorApp': rpadata})
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))

# def monitorApp(request):
#     if request.user.is_authenticated:
#         rpadata = rpaappinfo.objects.all()
#         return render(request, 'drbotapp/monitorApp.html', {'monitorApp': rpadata})
#         # return HttpResponseRedirect(reverse('index'))
#     else:
#         # Nothing has been provided for username or password.
#         # loginpg = UserForm()
#         # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
#         return HttpResponseRedirect(reverse('index'))



def forgot(request):
    auth.logout(request)
    return redirect("password_reset")

@login_required
def charts(request):
    rpadata = rpabotmachine.objects.all()
    return render(request, 'drbotapp/Chartpage.html',{'chartMachData': rpadata})
@login_required
def monitorServer(request):
    serverdata = rpaserverConfig.objects.all()
    devicedata = rpadevice.objects.all()
    fileidinfo = rpafileid.objects.all()
    scheduleinfo = scheduleBot.objects.all()
    return render(request,'drbotapp/monitorServer.html',{'monitorSvr':serverdata,'deviceinfo':devicedata,'fileidinfo':fileidinfo,'scheduleinfo':scheduleinfo})

# @login_required
# def manageServer(request):
#     if request.user.is_authenticated:
#         if request.method == "POST":
#             rpalob = request.POST.get('rpalob')
#             rpaname = request.POST.get('rpaname')
#             rpaUrl = request.POST.get('rpaUrl')
#             rpauser = request.POST.get('rpauser')
#             rpapassword = request.POST.get('rpapassword')
#             print(rpalob,rpaname)
#             serverinfo = rpaserverConfig(rpalob=rpalob, rpaname=rpaname, rpaUrl=rpaUrl,rpauser = rpauser,rpapassword=rpapassword)
#             serverinfo.save()
#             messages.success(request, 'Data Saved!')
#         rpasvrr = rpaserverConfig.objects.all()
#         return render(request, 'drbotapp/monitorServer.html', {'monitorSvr': rpasvrr})
#     else:
#         # Nothing has been provided for username or password.
#         # loginpg = UserForm()
#         # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
#         return HttpResponseRedirect(reverse('index'))

@login_required
def manageServer(request):
    if request.user.is_authenticated:
        # messages.info(request, 'Server!')
        if request.method == "POST":
            # messages.info(request, 'In POST!')
            rpaserverForm = rpaserverConfigForm(request.POST)
            if 'btnserveradd' in request.POST:
                # messages.info(request, 'In Server Add!')
                if rpaserverForm.is_valid():
                    rpaserverForm.save()
            if 'btndeviceadd' in request.POST:
                # messages.info(request, 'In Device Add!')
                servername = request.POST.get('RPAServername')
                serverinfo = rpaserverConfig.objects.get(rpaname=servername)
                Authenticateobj = Authenticate()
                token = Authenticateobj.authenticate(serverinfo.rpauser, serverinfo.rpapassword, serverinfo.rpaUrl)
                hostname = request.POST.get('hostname')
                user = serverinfo.rpauser
                RPAServername = serverinfo.rpaUrl
                DeviceIDobj = DeviceID()
                Deviceid = DeviceIDobj.deviceID(token, hostname, RPAServername)
                rpadeviceForm = rpadevice(hostname=hostname, Username=user, DeviceID=Deviceid, RPAServername=serverinfo)
                rpadeviceForm.save()
        deviceform = rpadeviceConfigForm()
        serverform = rpaserverConfigForm()
        deviceinfo = rpadevice.objects.all()
        rpasvrr = rpaserverConfig.objects.all()
        fileidinfo = rpafileid.objects.all()
        context = {
            'serverdetails': rpasvrr,
            'serverform': serverform,
            'deviceform':deviceform,
            # 'deviceinfo':deviceinfo,
            # 'fileidinfo': fileidinfo,
        }
        # messages.success(request, 'Data Saved!')
        return render(request, 'drbotapp/monitorServer.html', context)
    else:
        return HttpResponseRedirect(reverse('index'))

@login_required
def deleteServerID(request, id=None):
    # instance = get_object_or_404(rpaserverConfig,id=id)
    # instance.deleted()
    serverinfo = rpaserverConfig.objects.get(id=id)
    serverinfo.delete()
    messages.success(request, 'Data Saved!')
    rpasvrr = rpaserverConfig.objects.all()
    return render(request, 'drbotapp/monitorServer.html', {'monitorSvr': rpasvrr})

@login_required
def Authenticating(request,id=None):
    serverinfo = rpaserverConfig.objects.get(id=id)
    print(serverinfo.rpauser)
    print(serverinfo.rpaUrl)
    Authenticateobj = Authenticate()
    Token = Authenticateobj.authenticate(serverinfo.rpauser,serverinfo.rpapassword,serverinfo.rpaUrl)
    print('.......After authentication method executed.......')
    print(Token)
    return  render(request,'drbotapp/monitorServer.html',{'Token':Token,'url':serverinfo.rpaUrl,'username':serverinfo.rpauser})

@login_required
def Device(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            hostname = request.POST.get('hostname')
            token = request.POST.get('Token')
            user = request.POST.get('username')
            RPAServername = request.POST.get('url')
            print(RPAServername)
            print(hostname)
            DeviceIDobj = DeviceID()
            Deviceid = DeviceIDobj.deviceID(token,hostname,RPAServername)
            print('....Device....')
            print(Deviceid)
            deviceinfo = rpadevice(hostname=hostname, Username=user, DeviceID=Deviceid, RPAServername=RPAServername)
            deviceinfo.save()
        rpadeviceinfo = rpadevice.objects.filter(DeviceID=Deviceid).values()
        serverinfo = rpaserverConfig.objects.all()
        context = {'servername':RPAServername, 'user':user, 'token':token, 'deviceid':Deviceid}
        return  render(request,'drbotapp/monitorServer.html', {'deviceinfo':rpadeviceinfo, 'context':context, 'monitorSvr':serverinfo})
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))

@login_required
def deleteDeviceID(request, id=None):
    # instance = get_object_or_404(rpaserverConfig,id=id)
    # instance.deleted()
    deviceinfo = rpadevice.objects.get(id=id)
    deviceinfo.delete()
    messages.success(request, 'Data Saved!')
    rpadev = rpadevice.objects.all()
    serverinfo = rpaserverConfig.objects.all()
    return render(request, 'drbotapp/monitorServer.html', {'deviceinfo': rpadev,'monitorSvr':serverinfo})

@login_required
def FileID(request):
    # messages.info(request, 'In btnbotfile!')
    if request.user.is_authenticated:
        if request.method == "POST":
            # messages.info(request, 'In btnbotfile!')
            if 'btnbot' in request.POST:
                # messages.info(request, 'In btnbotfile!')
                servername = request.POST.get('RPAServername')
                serverinfo = rpaserverConfig.objects.get(rpaname=servername)
                print(serverinfo.rpauser)
                Authenticateobj = Authenticate()
                token = Authenticateobj.authenticate(serverinfo.rpauser, serverinfo.rpapassword, serverinfo.rpaUrl)
                filename = request.POST.get('filename')
                productionv = request.POST.get('productionv')
                if productionv == 'on':
                    prodVersion = True
                else:
                    prodVersion = False
                # messages.info(request, prodVersion)
                # token = request.POST.get('Token')
                # username = request.POST.get('username')
                # deviceid = request.POST.get('deviceid')
                url = serverinfo.rpaUrl
                FileIDobj = File()
                fileid = FileIDobj.fileID(token,filename,url)
                fileinfo = rpafileid(filename=filename, fileID=fileid, prodVersion=prodVersion,RPAServername=serverinfo)
                fileinfo.save()
            deviceform = rpadeviceConfigForm()
            serverform = rpaserverConfigForm()
            deviceinfo = rpadevice.objects.all()
            rpasvrr = rpaserverConfig.objects.all()
            fileidinfo = rpafileid.objects.all()
            context = {'fileidinfo':fileidinfo,
                        'deviceform': deviceform,
                        'deviceinfo':deviceinfo,
                       'serverdetails': rpasvrr,
                       'serverform': serverform,
                       }
        return render(request, 'drbotapp/monitorServer.html',context)
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))
@login_required
def deleteFileID(request, id=None):
    # instance = get_object_or_404(rpaserverConfig,id=id)
    # instance.deleted()
    fileinfo = rpafileid.objects.get(id=id)
    fileinfo.delete()
    messages.success(request, 'Data Saved!')
    fileidinfo = rpafileid.objects.all()
    deviceinfo = rpadevice.objects.all()
    serverinfo = rpaserverConfig.objects.all()
    return render(request, 'drbotapp/monitorServer.html', {'fileidinfo': fileidinfo, 'deviceinfo':deviceinfo, 'monitorSvr':serverinfo})


@login_required
def Schedule(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            servername = request.POST.get('RPAServername')
            serverinfo = rpaserverConfig.objects.get(rpaname=servername)
            Authenticateobj = Authenticate()
            token = Authenticateobj.authenticate(serverinfo.rpauser, serverinfo.rpapassword, serverinfo.rpaUrl)
            hostname = request.POST.get('devicename')
            deviceinfo = rpadevice.objects.get(hostname=hostname)
            filename = request.POST.get('filename')
            # fileidinfo = rpafileid.objects.get(filename=filename)
            user = serverinfo.rpauser
            RPAServerurl = serverinfo.rpaUrl
            DeviceIDobj = DeviceID()
            deviceid = DeviceIDobj.deviceID(token, deviceinfo.hostname, RPAServerurl)
            FileIDobj = File()
            fileid = FileIDobj.fileID(token, filename, RPAServerurl)
            # token = request.POST.get('Token')
            # url = request.POST.get('url')
            # deviceid = DeviceIDobj.deviceID(token, hostname, RPAServername)
            # fileid = request.POST.get('fileid')
            name = request.POST.get('filename')
            startdate = request.POST.get('startdate')
            enddate = request.POST.get('enddate')
            starttime = request.POST.get('starttime')
            description = request.POST.get('description')
            username = request.POST.get('username')
            rdpEnabled = 'true'
            scheduletype = 'NONE'
            repeatenabled = 'false'
            status = 'ACTIVE'
            timezone = 'Turkey'
            messages.info(request,  fileid+ "  " +deviceid+ "  " +name+ "  " +startdate+ "  " +enddate+ "  " +starttime+ "  " +description+ "  " +rdpEnabled+ "  " +scheduletype+ "  " +repeatenabled+ "  " +status+ "  " +timezone + "  " + RPAServerurl)
            scheduleidobj = ScheduleBot()
            scheduleid = scheduleidobj.schedulebot(token,fileid,deviceid,name,startdate,enddate,starttime,description,rdpEnabled,scheduletype,repeatenabled,status,timezone,RPAServerurl)
            print('....scheduleid....')
            print(scheduleid)
            ScheduleIdInfo = scheduleBot(name=name,fileId=fileid,scheduleId=scheduleid,startDate=startdate,endDate=enddate,startTime=starttime,description=description,rdpEnabled=rdpEnabled,scheduleType=scheduletype,repeatEnabled=repeatenabled,status=status,timeZone=timezone,deviceIds=deviceinfo)
            ScheduleIdInfo.save()
        scheduleidinfo = scheduleBot.objects.all()
        context = {'scheduleinfo':scheduleidinfo}
        return render(request, 'drbotapp/monitorServer.html',context)
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))

@login_required
def deleteScheduleID(request, id=None):
    # instance = get_object_or_404(rpaserverConfig,id=id)
    # instance.deleted()
    scheduleinfo = scheduleBot.objects.get(id=id)
    scheduleinfo.delete()
    messages.success(request, 'Data Saved!')
    scheduleinfo = scheduleBot.objects.all()
    deviceinfo = rpadevice.objects.all()
    serverinfo = rpaserverConfig.objects.all()
    return render(request, 'drbotapp/monitorServer.html', {'scheduleinfo': scheduleinfo, 'deviceinfo':deviceinfo, 'monitorSvr':serverinfo})

@login_required
def deploy(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            deviceid = request.POST.get('deviceid')
            fileid = request.POST.get('fileid')
            token = request.POST.get('Token')
            url = request.POST.get('url')
            filename  = request.POST.get('filename')
            deployobj = Deploy()
            automationid = deployobj.deploybot(token,fileid,deviceid,url)
            Activitiesobj = BotActivities()
            botactivities = Activitiesobj.botactivity(token,fileid,deviceid,url)
            # automationid = json.dumps(automationidjson)
            # botactivities = json.dumps(botactivitiesjson)
            print(filename)
            print('.....automationid......')
            print(automationid)
            print('....botactivity....')
            # print(botactivities['list'][1])
        contextdeploy = {'filename':filename,'deviceid':deviceid,'botactivities':botactivities['list'][1]}
        # print(contextdeploy.filename)
        # print('..........')
        # print(contextdeploy.botactivities)
        deviceinfo = rpadevice.objects.all()
        serverinfo = rpaserverConfig.objects.all()
        return  render(request, 'drbotapp/monitorServer.html',{'filename':filename,'botactivities':botactivities['list'][1]['status'],'deviceinfo':deviceinfo,'monitorSvr':serverinfo})
    else:
        # Nothing has been provided for username or password.
        # loginpg = UserForm()
        # return render(request, 'drbotapp/Login.html', {'drbotlogin': loginpg})
        return HttpResponseRedirect(reverse('index'))

import requests
from.Authenticate import FinalToken

def audit():

    headers = {'content-type': 'application/json', 'X-Authorization': FinalToken}

    payload = {
      "sort": [
        {
          "field": "createdOn",
          "direction": "desc"
        }
      ],
      "filter": {
        "operator": "and",
        "operands": [
          {
            "operator": "gt",
            "field": "createdOn",
            "value": "2019-12-01T00:00:00.001Z"
          },
          {
            "operator": "lt",
            "field": "createdOn",
            "value": "2019-12-31T23:59:59.999Z"
          },
          {
            "operator": "eq",
            "field": "status",
            "value": "Unsuccessful"
          },
          {
            "operator": "substring",
            "field": "activityType",
            "value": "LOGIN"
          }
        ]
      },
      "fields": [],
      "page": {
        "length": "1000",
        "offset": "0"
      }
    }

    r = requests.post(url='http://loxtipl001087.mioffice.cn/v1/audit/messages/list', headers=headers, json=payload, verify=False)

    r = r.json()
    print(r)

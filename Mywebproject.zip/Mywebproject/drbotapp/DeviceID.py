import requests
import re
import json

class DeviceID:
    def deviceID(self,FinalToken,hostname,url):

        # filename = "external.config"
        #
        # contents = open(filename).read()
        #
        # config = eval(contents)

        hostname = hostname

        headers = {'content-type': 'application/json' ,'X-Authorization': FinalToken}

        payload = {'filter':{'operator':'eq', 'value':hostname, 'field':'hostName'}}


        r = requests.post(url='{}/v2/devices/list'.format(url), headers=headers, json=payload, verify=False)

        device = r.text
        print(device)


        pattren= re.compile(',\s+\{\s+"id"\:\s+"([0-9]+)"')
        Extrctd_id= pattren.search(device)
        Device_Id=Extrctd_id.group(1)
        print('Device ID is  ' +Device_Id)

        print(r.text)
        return Device_Id

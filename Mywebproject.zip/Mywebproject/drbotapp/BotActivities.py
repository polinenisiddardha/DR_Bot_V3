import requests

class BotActivities:
  def botactivity(self,FinalToken, File_Id, Device_Id, url):
    headers = {'content-type': 'application/json', 'X-Authorization': FinalToken}

    payload = {
      "filter": {
        "operator": "and",
        "operands": [
          {
            "operator": "eq",
            "value": Device_Id,
            "field": "deviceId"
          },
          {
            "operator": "eq",
            "value": File_Id,
            "field": "fileId"
          }
        ]
      }
    }

    r = requests.post(url='{}/v2/activity/list'.format(url), headers=headers, json=payload, verify=False)

    r = r.json()

    # print(r)

    # print(r['list'][1]['id'])
    return r

from django import forms
from django.contrib.auth.models import User
from .models import tblConfig,rpaserverConfig,rparobotconfig, rpabotmachine, rpaappinfo,rpadevice,rpafileid,scheduleBot


class UserForm(forms.ModelForm):

    password = forms.CharField(widget=forms.PasswordInput())

    class Meta():
        model = User
        fields = ('username','password')
        # labels = {'username': 'User Name','password': 'Password'}

class UserFormRegister(forms.ModelForm):

    password = forms.CharField(widget=forms.PasswordInput())

    class Meta():
        model = User
        fields = ('username', 'email', 'password')
        # labels = {'username': 'User Name','password': 'Password'}




class tblConfigForm(forms.ModelForm):
    botname =forms.CharField()
    botdescription = forms.CharField()
    application = forms.CharField()

    class Meta():
        model = tblConfig
        fields = ('botname','botdescription','application')


        # class UserForm(forms.Form):
#     username = forms.CharField(label='User Name', max_length=100)
#     password = forms.CharField(label='Password', max_length=32,widget=forms.PasswordInput)

class rpaserverConfigForm(forms.ModelForm):
    rpapassword = forms.CharField(label='PASSWORD: ', widget=forms.PasswordInput)
    class Meta():
        model = rpaserverConfig
        fields = ('rpalob','rpaname','rpaUrl','rpauser','rpapassword')
        labels = {'rpalob':'LOB: ','rpaname': 'SERVER: ','rpaUrl': 'URI: ','rpauser': 'USER: ','rpapassword': 'PASSWORD: '}
        # widgets = {'rpapassword': forms.PasswordInput(),}
        # class UserForm(forms.Form):
#     username = forms.CharField(label='User Name', max_length=100)
#     password = forms.CharField(label='Password', max_length=32,widget=forms.PasswordInput)


class rpadeviceConfigForm(forms.ModelForm):
    hostname =forms.CharField()
    # Username = forms.CharField()
    # DeviceID = forms.CharField()
    RPAServername = forms.ModelMultipleChoiceField(queryset = rpaserverConfig.objects.all())
    # RPAServername = forms.ModelChoiceField(queryset = rpaserverConfig.objects.all())
    class Meta():
        model = rpadevice
        fields = ('hostname','Username','DeviceID','RPAServername')
        # labels = {'hostname': 'HOST NAME: ','Username': 'USER :','DeviceID': 'DEVICE ID ','RPAServername': 'SERVER: '}



class rpabotconfigForm(forms.ModelForm):
    botname =forms.CharField()
    # botdesc = forms.CharField()
    botServerID = forms.CharField()

    class Meta():
        model = rparobotconfig
        fields = ('botname','botdesc','botServerID')

##Class form for Rpa Machine

class rpabotmachineForm(forms.ModelForm):
    machinename =forms.CharField()
    machineIP = forms.CharField()
    machinedesc = forms.CharField()
    RPAServerID = forms.CharField()
    class Meta():
        model = rpabotmachine
        fields = ('machinename','machineIP','machinedesc','RPAServerID')

##Class form for  Application

class rpaappinfoForm(forms.ModelForm):
    appname =forms.CharField()
    appdesc = forms.CharField()
    applob = forms.CharField()

    class Meta():
        model = rpaappinfo
        fields = ('appname','appdesc','applob')


class rpafileidForm(forms.ModelForm):
    filename =forms.CharField()
    fileID = forms.CharField()
    prodVersion = forms.BooleanField()
    RPAServername = forms.ModelMultipleChoiceField(queryset=rpaserverConfig.objects.all())

    class Meta():
        model = rpafileid
        fields = ('filename','fileID','prodVersion','RPAServername')


class rpascheduleForm(forms.ModelForm):
    startDate = forms.CharField()
    endDate = forms.CharField()
    startTime = forms.CharField()
    description = forms.CharField()
    deviceIds = forms.ModelMultipleChoiceField(queryset=rpadevice.objects.all())

    class Meta():
        model = scheduleBot
        fields = ('name','fileId','scheduleId','startDate','endDate','startTime','description','rdpEnabled','scheduleType','repeatEnabled','status','timeZone','deviceIds')